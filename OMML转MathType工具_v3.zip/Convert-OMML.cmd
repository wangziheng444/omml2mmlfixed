@echo off
chcp 65001 >nul
"%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" -STA -NoProfile -ExecutionPolicy Bypass -File "%~dp0Convert-OMML.ps1" %*
echo.
pause
