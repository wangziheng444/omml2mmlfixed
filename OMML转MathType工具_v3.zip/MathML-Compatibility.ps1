﻿# Normalize only known MathType import incompatibilities; preserve formula symbols.
function ConvertTo-MathTypeCompatibleMathML {
    param(
        [Parameter(Mandatory=$true)][string]$MathML,
        [ref]$Report
    )
    $taskMathNamespace = 'http://www.w3.org/1998/Math/MathML'
    $taskXML = New-Object System.Xml.XmlDocument
    $taskXML.PreserveWhitespace = $true
    $taskXML.LoadXml($MathML)
    $taskNamespaces = New-Object System.Xml.XmlNamespaceManager($taskXML.NameTable)
    $taskNamespaces.AddNamespace('mm', $taskMathNamespace)
    $taskBars = 0
    $taskSpaces = 0
    foreach ($taskMover in @($taskXML.SelectNodes('//mm:mover[@accent="true"]', $taskNamespaces))) {
        $taskChildren = $taskMover.SelectNodes('./*')
        if ($taskChildren.Count -eq 2 -and $taskChildren.Item(1).LocalName -in @('mi','mo') -and $taskChildren.Item(1).NamespaceURI -eq $taskMathNamespace -and $taskChildren.Item(1).SelectNodes('./*').Count -eq 0 -and $taskChildren.Item(1).InnerText -ceq [string][char]0x203E) {
            $taskMarker = $taskXML.CreateElement('mml', 'mo', $taskMathNamespace)
            $taskMarker.InnerText = [string][char]0x00AF
            $taskMarker.SetAttribute('stretchy', 'true')
            $taskMover.ReplaceChild($taskMarker, $taskChildren.Item(1)) | Out-Null
            $taskBars++
        }
    }
    # EM QUAD, FOUR-PER-EM SPACE, THIN SPACE, ZERO WIDTH SPACE.
    # Widths are explicit MathML spacing, rather than glyphs in an operator font.
    $taskSpaceWidths = @{ 0x2001='1em'; 0x2005='0.25em'; 0x2009='0.166667em'; 0x200B='0em' }
    foreach ($taskToken in @($taskXML.SelectNodes('//mm:mi | //mm:mo | //mm:mn | //mm:mtext', $taskNamespaces))) {
        $taskText = $taskToken.InnerText
        if ($taskText.Length -eq 1 -and $taskToken.SelectNodes('./*').Count -eq 0) {
            $taskCode = [int][char]$taskText[0]
            if ($taskSpaceWidths.ContainsKey($taskCode)) {
                $taskSpace = $taskXML.CreateElement('mml', 'mspace', $taskMathNamespace)
                $taskSpace.SetAttribute('width', $taskSpaceWidths[$taskCode])
                $taskToken.ParentNode.ReplaceChild($taskSpace, $taskToken) | Out-Null
                $taskSpaces++
            }
        }
    }
    if ($null -ne $Report) {
        $Report.Value = [pscustomobject]@{ Bars=$taskBars; Spaces=$taskSpaces }
    }
    return $taskXML.OuterXml
}
