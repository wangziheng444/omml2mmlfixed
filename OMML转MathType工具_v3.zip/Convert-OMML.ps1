﻿# Version 3: MathML overbar/space compatibility plus bounded OLE activation retry.
# For this computer: 32-bit WPS + MathType in E:\mathtype.
# Converts native OMML equations in the document body, including tables.
# The source is copied before opening; results are saved to a new .docx.
param(
    [Parameter(Position=0, ValueFromRemainingArguments=$true)]
    [string[]]$DocumentPaths,
    [string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
$taskStage = '初始化'
$taskIndex = $null
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
Write-Host 'OMML 转 MathType 工具 v3'
. (Join-Path $PSScriptRoot 'MathML-Compatibility.ps1')
if ([IntPtr]::Size -ne 4) { throw '请使用配套的 Convert-OMML.cmd 启动，工具需要 32 位 PowerShell。' }
if (-not $DocumentPaths) {
    $DocumentPaths = @(Read-Host '请把一个 .docx 文档拖到窗口中，再按回车')
}
$taskMathTypeRoot = 'E:\mathtype'
$taskStylesheet = Join-Path $taskMathTypeRoot 'Office Support\OMML2MML.XSL'
$taskBlankEquation = Join-Path $taskMathTypeRoot 'Office Support\BlankEqn.doc'
foreach ($taskRequiredPath in @($taskStylesheet, $taskBlankEquation, (Join-Path $taskMathTypeRoot 'MathPage\32\MathPage.wll'))) {
    if (-not (Test-Path -LiteralPath $taskRequiredPath -PathType Leaf)) { throw "缺少文件：$taskRequiredPath" }
}
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CodexOMMLNative32 {
    [DllImport(@"E:\mathtype\MathPage\32\MathPage.wll", CallingConvention=CallingConvention.StdCall)]
    public static extern int MTInitAPI(short options, short timeout);
    [DllImport(@"E:\mathtype\MathPage\32\MathPage.wll", CallingConvention=CallingConvention.StdCall)]
    public static extern int MTSetEqnFromLangStr(IntPtr equation, short language, IntPtr text, int length);
    [DllImport(@"E:\mathtype\MathPage\32\MathPage.wll", CallingConvention=CallingConvention.StdCall)]
    public static extern int MTCloseOleObject(int saveOptions, IntPtr equation);
    [DllImport(@"E:\mathtype\MathPage\32\MathPage.wll", CallingConvention=CallingConvention.StdCall)]
    public static extern int MTTermAPI();
}
'@
function Get-TaskMathTypeCount($Document) {
    $taskCount = 0
    for ($taskShapeIndex = 1; $taskShapeIndex -le $Document.InlineShapes.Count; $taskShapeIndex++) {
        $taskInline = $Document.InlineShapes.Item($taskShapeIndex)
        if ($taskInline.Type -eq 1 -and $taskInline.OLEFormat.ProgID -eq 'Equation.DSMT4') { $taskCount++ }
    }
    return $taskCount
}
$taskApp = $null
$taskOwnedApp = $false
$taskInitialized = $false
$taskFailures = 0
try {
    $taskApp = New-Object -ComObject kwps.Application
    if ($taskApp.Documents.Count -ne 0) { throw 'WPS 自动化实例中存在打开的文档；为避免影响这些文档，工具已停止。' }
    $taskOwnedApp = $true
    $taskApp.Visible = $false
    $taskInit = [CodexOMMLNative32]::MTInitAPI(0, 30)
    if ($taskInit -le 0) { throw "MathType 接口初始化失败：$taskInit" }
    $taskInitialized = $true
    $taskStyle = New-Object -ComObject Msxml2.DOMDocument.3.0
    $taskStyle.async = $false
    if (-not $taskStyle.load($taskStylesheet)) { throw '无法读取 OMML2MML.XSL。' }
    foreach ($taskInput in $DocumentPaths) {
        $taskDoc = $null
        $taskScratch = $null
        $taskIndex = $null
        $taskActivationAttempt = $null
        $taskStage = '读取文档路径'
        $taskCompatibleBars = 0
        $taskCompatibleSpaces = 0
        try {
            $taskSourcePath = (Resolve-Path -LiteralPath $taskInput.Trim().Trim('"')).Path
            if ([IO.Path]::GetExtension($taskSourcePath) -ine '.docx') { throw '当前工具接受 .docx 文档，请先将其他格式另存为 .docx。' }
            $taskDestinationDirectory = if ($OutputDirectory) { (Resolve-Path -LiteralPath $OutputDirectory).Path } else { [IO.Path]::GetDirectoryName($taskSourcePath) }
            $taskName = [IO.Path]::GetFileNameWithoutExtension($taskSourcePath)
            $taskStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            $taskSuffix = [Guid]::NewGuid().ToString('N').Substring(0, 6)
            $taskOutput = Join-Path $taskDestinationDirectory ($taskName + '_MathType_' + $taskStamp + '_' + $taskSuffix + '.docx')
            if (Test-Path -LiteralPath $taskOutput) { throw "目标文件已存在：$taskOutput" }
            $taskScratch = Join-Path ([IO.Path]::GetTempPath()) ('CodexOMML_' + [Guid]::NewGuid().ToString('N') + '.docx')
            Copy-Item -LiteralPath $taskSourcePath -Destination $taskScratch
            $taskStage = '打开文档副本'
            $taskDoc = $taskApp.Documents.Open($taskScratch, $false, $false)
            $taskStage = '检测正文公式'
            $taskTotal = $taskDoc.OMaths.Count
            $taskPreviousMathTypeCount = Get-TaskMathTypeCount $taskDoc
            Write-Host "文档：$taskSourcePath"
            Write-Host "检测到正文 OMML 公式：$taskTotal"
            if ($taskTotal -eq 0) {
                Write-Host '正文中没有可转换的 OMML 公式，未生成新文件。'
                continue
            }
            for ($taskIndex = $taskTotal; $taskIndex -ge 1; $taskIndex--) {
                $taskActivationAttempt = 0
                $taskStage = '获取公式范围'
                $taskRange = $taskDoc.OMaths.Item($taskIndex).Range
                $taskSourceXML = New-Object -ComObject Msxml2.DOMDocument.3.0
                $taskSourceXML.async = $false
                $taskStage = '读取 OMML'
                if (-not $taskSourceXML.loadXML([string]$taskRange.WordOpenXML)) { throw "公式 $taskIndex 的 OMML 读取失败。" }
                $taskStage = 'OMML 转 MathML'
                $taskMathML = [string]$taskSourceXML.transformNode($taskStyle.documentElement)
                $taskStage = '上横线和间距兼容处理'
                $taskCompatibilityReport = $null
                $taskMathML = ConvertTo-MathTypeCompatibleMathML -MathML $taskMathML -Report ([ref]$taskCompatibilityReport)
                $taskCompatibleBars += $taskCompatibilityReport.Bars
                $taskCompatibleSpaces += $taskCompatibilityReport.Spaces

                $taskCheckXML = New-Object -ComObject Msxml2.DOMDocument.3.0
                if (-not $taskCheckXML.loadXML($taskMathML) -or $taskCheckXML.documentElement.baseName -ne 'math') { throw "公式 $taskIndex 的 MathML 转换失败。" }
                $taskStage = '替换原生公式'
                $taskRange.Delete() | Out-Null
                $taskStage = '插入 MathType 对象'
                $taskRange.InsertFile($taskBlankEquation, 'MTBlankEqn')
                $taskRange.Expand(2) | Out-Null
                if ($taskRange.InlineShapes.Count -ne 1) { throw "公式 $taskIndex 的 MathType 对象插入失败。" }
                $taskShape = $taskRange.InlineShapes.Item(1)
                if ($taskShape.OLEFormat.ProgID -ne 'Equation.DSMT4') { throw '插入的对象类型不符合预期。' }
                $taskStage = '启动 MathType 对象'
                $taskObject = $null
                for ($taskActivationAttempt = 1; $taskActivationAttempt -le 4; $taskActivationAttempt++) {
                    try {
                        $taskStage = '启动 MathType 对象'
                        $taskShape.OLEFormat.DoVerb(2)
                        $taskStage = '取得 MathType 对象接口'
                        $taskObject = $taskShape.OLEFormat.Object
                        if ($null -eq $taskObject) {
                            throw [Runtime.InteropServices.COMException]::new('MathType 对象接口尚未就绪。', -2147417846)
                        }
                        break
                    } catch {
                        $taskActivationError = $_.Exception
                        while ($taskActivationError.InnerException) { $taskActivationError = $taskActivationError.InnerException }
                        $taskActivationHResult = $taskActivationError.HResult.ToString('X8')
                        if ($taskActivationHResult -notin @('80004005', '80080005', '80010001', '8001010A') -or $taskActivationAttempt -eq 4) { throw }
                        Write-Host "转换 $($taskTotal - $taskIndex + 1)/$taskTotal（原文公式 $taskIndex）：MathType 对象启动失败（$taskActivationHResult），正在重试 $taskActivationAttempt/3。"
                        Start-Sleep -Milliseconds (400 * $taskActivationAttempt)
                    }
                }
                $taskStage = '取得 MathType 对象接口'
                $taskDispatch = [Runtime.InteropServices.Marshal]::GetIDispatchForObject($taskObject)
                $taskBuffer = [IntPtr]::Zero
                try {
                    $taskBuffer = [Runtime.InteropServices.Marshal]::StringToCoTaskMemUni($taskMathML)
                    $taskStage = '写入 MathML'
                    $taskSet = [CodexOMMLNative32]::MTSetEqnFromLangStr($taskDispatch, 2, $taskBuffer, $taskMathML.Length)
                    if ($taskSet -ne 0) { throw "公式 $taskIndex 写入失败，MathType 返回：$taskSet" }
                    $taskStage = '关闭并保存 MathType 对象'
                    $taskClose = [CodexOMMLNative32]::MTCloseOleObject(1, $taskDispatch)
                    if ($taskClose -ne 0) { throw "公式 $taskIndex 保存失败，MathType 返回：$taskClose" }
                } finally {
                    if ($taskBuffer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::FreeCoTaskMem($taskBuffer) }
                    [Runtime.InteropServices.Marshal]::Release($taskDispatch) | Out-Null
                }
                Write-Host "已转换 $($taskTotal - $taskIndex + 1)/$taskTotal"
            }
            if ($taskDoc.OMaths.Count -ne 0 -or (Get-TaskMathTypeCount $taskDoc) -ne ($taskPreviousMathTypeCount + $taskTotal)) { throw '保存前的公式数量检查失败。' }
            $taskStage = '保存新文档'
            $taskDoc.SaveAs($taskOutput, 12)
            $taskDoc.Close(0)
            $taskDoc = $null
            $taskStage = '重新打开验证'
            $taskDoc = $taskApp.Documents.Open($taskOutput, $false, $true)
            if ($taskDoc.OMaths.Count -ne 0 -or (Get-TaskMathTypeCount $taskDoc) -ne ($taskPreviousMathTypeCount + $taskTotal)) { throw "重新打开后校验失败，请勿使用结果文件：$taskOutput" }
            Write-Host "兼容处理：上横线 $taskCompatibleBars 处，特殊空白 $taskCompatibleSpaces 处。"
            Write-Host "转换并重新打开验证成功：$taskOutput"
        } catch {
            $taskFailures++
            Write-Host "处理失败：$taskInput" -ForegroundColor Red
            Write-Host $_.Exception.Message -ForegroundColor Red
            $taskRootException = $_.Exception
            while ($taskRootException.InnerException) { $taskRootException = $taskRootException.InnerException }
            Write-Host ("失败步骤：$taskStage；错误码：" + $taskRootException.HResult.ToString('X8')) -ForegroundColor Red
            if ($null -ne $taskIndex -and $taskIndex -ge 1) { Write-Host "原文公式序号：$taskIndex；启动尝试次数：$taskActivationAttempt" -ForegroundColor Red }
        } finally {
            if ($taskDoc) { try { $taskDoc.Close(0) } catch {} }
            if ($taskScratch -and (Test-Path -LiteralPath $taskScratch)) { Remove-Item -LiteralPath $taskScratch -Force }
        }
    }
} catch {
    $taskFailures++
    Write-Host $_.Exception.Message -ForegroundColor Red
    $taskRootException = $_.Exception
    while ($taskRootException.InnerException) { $taskRootException = $taskRootException.InnerException }
    Write-Host ("失败步骤：$taskStage；错误码：" + $taskRootException.HResult.ToString('X8')) -ForegroundColor Red
    if ($null -ne $taskIndex -and $taskIndex -ge 1) { Write-Host "原文公式序号：$taskIndex；启动尝试次数：$taskActivationAttempt" -ForegroundColor Red }
} finally {
    if ($taskApp -and $taskOwnedApp) { try { $taskApp.Quit() } catch {} }
    if ($taskInitialized) { [CodexOMMLNative32]::MTTermAPI() | Out-Null }
}
if ($taskFailures -gt 0) { exit 1 }
exit 0
