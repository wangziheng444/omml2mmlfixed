﻿function Get-TaskEquationBreakPlan {
    param([Parameter(Mandatory=$true)][string]$SourcePath)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $taskArchive = [IO.Compression.ZipFile]::OpenRead($SourcePath)
    try {
        $taskEntry = $taskArchive.GetEntry('word/document.xml')
        if (-not $taskEntry) { throw 'DOCX 缺少正文 XML。' }
        $taskStream = $taskEntry.Open()
        try {
            $taskXML = New-Object Xml.XmlDocument
            $taskXML.PreserveWhitespace = $true
            $taskXML.Load($taskStream)
        } finally { $taskStream.Dispose() }
    } finally { $taskArchive.Dispose() }
    $taskMathNS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
    $taskWordNS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
    $taskNS = New-Object Xml.XmlNamespaceManager($taskXML.NameTable)
    $taskNS.AddNamespace('m',$taskMathNS)
    $taskNS.AddNamespace('w',$taskWordNS)
    $taskNS.AddNamespace('o','urn:schemas-microsoft-com:office:office')
    $taskNodes = $taskXML.SelectNodes('//w:body//m:oMath[not(ancestor::w:txbxContent)] | //w:body//o:OLEObject[@ProgID="Equation.DSMT4"][not(ancestor::w:txbxContent)]',$taskNS)
    $taskItems = @()
    $taskOMMLIndex = 0
    for ($taskOrdinal = 0; $taskOrdinal -lt $taskNodes.Count; $taskOrdinal++) {
        $taskFormula = $taskNodes.Item($taskOrdinal)
        if ($taskFormula.NamespaceURI -ne $taskMathNS) { continue }
        $taskOMMLIndex++
        $taskAllBreaks = $taskFormula.SelectNodes('.//w:br',$taskNS)
        if ($taskAllBreaks.Count -eq 0) { continue }
        $taskTrailingBreaks = 0
        for ($taskChildIndex = $taskFormula.ChildNodes.Count-1; $taskChildIndex -ge 0; $taskChildIndex--) {
            $taskRun = $taskFormula.ChildNodes.Item($taskChildIndex)
            if ($taskRun.NodeType -eq [Xml.XmlNodeType]::Whitespace -or $taskRun.NodeType -eq [Xml.XmlNodeType]::SignificantWhitespace) { continue }
            if ($taskRun.NamespaceURI -ne $taskMathNS -or $taskRun.LocalName -ne 'r') { break }
            $taskRunBreaks = 0
            $taskOnlyBreaks = $true
            foreach ($taskRunChild in $taskRun.ChildNodes) {
                if ($taskRunChild.NodeType -eq [Xml.XmlNodeType]::Whitespace -or $taskRunChild.NodeType -eq [Xml.XmlNodeType]::SignificantWhitespace) { continue }
                if (($taskRunChild.NamespaceURI -eq $taskMathNS -or $taskRunChild.NamespaceURI -eq $taskWordNS) -and $taskRunChild.LocalName -eq 'rPr') { continue }
                if ($taskRunChild.NamespaceURI -eq $taskWordNS -and $taskRunChild.LocalName -eq 'br') {
                    foreach ($taskAttribute in $taskRunChild.Attributes) {
                        if ($taskAttribute.NamespaceURI -eq 'http://www.w3.org/2000/xmlns/') { continue }
                        if ($taskAttribute.NamespaceURI -eq $taskWordNS -and $taskAttribute.LocalName -eq 'type' -and $taskAttribute.Value -eq 'textWrapping') { continue }
                        throw "公式 $taskOMMLIndex 包含尚未支持的换行属性，已停止以避免丢失。"
                    }
                    $taskRunBreaks++
                } else { $taskOnlyBreaks = $false; break }
            }
            if (-not $taskOnlyBreaks) { break }
            $taskTrailingBreaks += $taskRunBreaks
        }
        if ($taskTrailingBreaks -ne $taskAllBreaks.Count) { throw "公式 $taskOMMLIndex 包含内部手工换行，当前工具不能无损重建，已停止。" }
        $taskItems += [pscustomobject]@{Ordinal=$taskOrdinal+1;OriginalOMMLIndex=$taskOMMLIndex;Count=$taskTrailingBreaks}
    }
    return [pscustomobject]@{EquationCount=$taskNodes.Count;OMMLCount=$taskOMMLIndex;Items=@($taskItems)}
}

function Restore-TaskEquationBreaks {
    param([Parameter(Mandatory=$true)]$Document,[Parameter(Mandatory=$true)]$Plan)
    if ($Plan.Items.Count -eq 0) { return 0 }
    $taskShapes = New-Object 'Collections.Generic.List[object]'
    for ($taskShapeIndex=1; $taskShapeIndex -le $Document.InlineShapes.Count; $taskShapeIndex++) {
        $taskShape = $Document.InlineShapes.Item($taskShapeIndex)
        if ($taskShape.Type -eq 1 -and $taskShape.OLEFormat.ProgID -eq 'Equation.DSMT4') { $taskShapes.Add($taskShape) }
    }
    if ($taskShapes.Count -ne $Plan.EquationCount) { throw '恢复公式换行前的对象顺序数量检查失败。' }
    $taskRestored = 0
    foreach ($taskItem in @($Plan.Items | Sort-Object Ordinal -Descending)) {
        $taskShape = $taskShapes[$taskItem.Ordinal-1]
        $taskEnd = [int]$taskShape.Range.End
        $taskBreakRange = $Document.Range($taskEnd,$taskEnd)
        for ($taskBreakIndex=0; $taskBreakIndex -lt $taskItem.Count; $taskBreakIndex++) {
            $taskBreakRange.InsertBreak(6) | Out-Null
            $taskBreakRange.Collapse(0) | Out-Null
            $taskRestored++
        }
    }
    return $taskRestored
}
