﻿# Use the runtime switch documented in MathType's own MathML input translator.
# Latin-1 provides a reversible byte-to-character mapping; unchanged bytes stay exact.
function Get-TaskMathMLRuntimePlan {
    param([Parameter(Mandatory=$true)][byte[]]$Bytes)
    $taskEncoding = [Text.Encoding]::GetEncoding(28591)
    $taskText = $taskEncoding.GetString($Bytes)
    $taskMasked = [regex]::Replace($taskText, '(?s)/\*.*?\*/|(?m)//[^\r\n]*', [Text.RegularExpressions.MatchEvaluator]{
        param($taskMatch)
        return [regex]::Replace($taskMatch.Value,'[^\r\n]',' ')
    })
    $taskPatterns = [regex]::Match($taskMasked,'(?m)^[ \t]*patterns[ \t]*\{')
    if (-not $taskPatterns.Success) { throw '无法识别 MathType 输入转换器结构；未修改配置。' }
    $taskHeader = $taskMasked.Substring(0,$taskPatterns.Index)
    if (-not [regex]::IsMatch($taskHeader,'(?m)^[ \t]*input[ \t]*=[ \t]*"MathML"[ \t]*;')) { throw '转换器不是 MathML 输入配置；未修改配置。' }
    $taskAssignments = [regex]::Matches($taskMasked,'(?<!\w)max_run_time[ \t]*=[ \t]*(?<expression>[^;}\r\n]+)[ \t]*;')
    $taskBlocks = [regex]::Matches($taskHeader,'(?s)(?<!\w)debug\s*\{[^{}]*\}')
    if ($taskAssignments.Count -gt 1) { throw '发现多处自定义 max_run_time；未修改配置，请检查转换器。' }
    if ($taskAssignments.Count -eq 1) {
        $taskAssignment = $taskAssignments.Item(0)
        if ($taskBlocks.Count -ne 1 -or $taskAssignment.Index -lt $taskBlocks.Item(0).Index -or ($taskAssignment.Index+$taskAssignment.Length) -gt ($taskBlocks.Item(0).Index+$taskBlocks.Item(0).Length)) { throw '输入处理时限不在唯一已识别的 debug 块中；未修改配置。' }
        $taskNumber = [regex]::Match($taskAssignment.Groups['expression'].Value,'^[ \t]*(?<number>[0-9]+)[ \t]*$')
        [long]$taskValue = 0
        if (-not $taskNumber.Success -or -not [long]::TryParse($taskNumber.Groups['number'].Value,[ref]$taskValue) -or $taskValue -le 0) { throw '输入处理时限是特殊值或表达式；保留自定义配置，请手动确认。' }
        if ($taskValue -ge 30000) { return [pscustomobject]@{ Changed=$false; Milliseconds=$taskValue; Bytes=$Bytes } }
        $taskNumberIndex = $taskAssignment.Groups['expression'].Index + $taskNumber.Groups['number'].Index
        $taskUpdatedText = $taskText.Remove($taskNumberIndex,$taskNumber.Groups['number'].Length).Insert($taskNumberIndex,'30000')
    } else {
        if ($taskBlocks.Count -ne 0) { throw '已有未知 debug 配置；未修改转换器。' }
        $taskTemplate = [regex]::Matches($taskText.Substring(0,$taskPatterns.Index),'//debug(?<newline>\r?\n)//\{ max_run_time = 30000; \} // 30 seconds')
        if ($taskTemplate.Count -ne 1) { throw '未找到唯一的 MathType 官方 30 秒配置模板；未修改转换器。' }
        $taskMatch = $taskTemplate.Item(0)
        $taskReplacement = 'debug'+$taskMatch.Groups['newline'].Value+'{ max_run_time = 30000; } // 30 seconds'
        $taskUpdatedText = $taskText.Remove($taskMatch.Index,$taskMatch.Length).Insert($taskMatch.Index,$taskReplacement)
    }
    return [pscustomobject]@{ Changed=$true; Milliseconds=30000; Bytes=$taskEncoding.GetBytes($taskUpdatedText) }
}

function Get-TaskRuntimeHash {
    param([byte[]]$Bytes)
    $taskHasher = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($taskHasher.ComputeHash($Bytes)).Replace('-','').ToLowerInvariant() }
    finally { $taskHasher.Dispose() }
}

function Get-TaskMathMLHorizontalBracePlan {
    param([Parameter(Mandatory=$true)][byte[]]$Bytes)
    $taskEncoding = [Text.Encoding]::GetEncoding(28591)
    $taskText = $taskEncoding.GetString($Bytes)
    if (-not [regex]::IsMatch($taskText,'\AMathType Input Translator 1\.0: "Presentation MathML"')) { throw '无法识别 MathType MathML 输入转换器；未添加括号规则。' }
    $taskAnchor = '   munder_node => lim(slot($1),slot($2));'
    $taskMarker = '// Codex OMML v5 horizontal underbrace template'
    $taskRule = '   munder_node?(exists($2.char) && ($2.char==0x23DF || $2.char==0xFE38)) => hbrace(slot($1),slot());'
    $taskBlock = $taskMarker+"`r`n"+$taskRule+"`r`n"
    $taskMarkerCount = [regex]::Matches($taskText,[regex]::Escape($taskMarker)).Count
    if ($taskMarkerCount -gt 1) { throw '发现重复的下括号兼容规则；未修改配置。' }
    if ($taskMarkerCount -eq 1) {
        if ([regex]::Matches($taskText,[regex]::Escape($taskBlock+$taskAnchor)).Count -ne 1) { throw '已有下括号兼容规则被修改；保留该配置并停止。' }
        $taskCheckText = $taskText.Replace($taskBlock,'')
    } else { $taskCheckText = $taskText }
    $taskMasked = [regex]::Replace($taskCheckText, '(?s)/\*.*?\*/|(?m)//[^\r\n]*', [Text.RegularExpressions.MatchEvaluator]{
        param($taskMatch)
        return [regex]::Replace($taskMatch.Value,'[^\r\n]',' ')
    })
    if ([regex]::IsMatch($taskMasked,'(?<!\w)hbrace\b')) { throw '已有其他自定义水平括号规则；未覆盖配置。' }
    $taskRawAnchors = [regex]::Matches($taskCheckText,[regex]::Escape($taskAnchor))
    $taskActiveAnchors = [regex]::Matches($taskMasked,'(?m)^'+[regex]::Escape($taskAnchor)+'[ \t]*\r?$')
    if ($taskRawAnchors.Count -ne 1 -or $taskActiveAnchors.Count -ne 1 -or $taskRawAnchors.Item(0).Index -ne $taskActiveAnchors.Item(0).Index -or [regex]::Matches($taskMasked,'(?m)^[ \t]*munder_node[ \t]*=>').Count -ne 1) { throw '无法确认唯一的活动原始下标兜底规则；未修改配置。' }
    if ($taskMarkerCount -eq 1) { return [pscustomobject]@{ Changed=$false; Bytes=$Bytes } }
    # Native-tested MTEF template; preserve the base and any outer annotation.
    # Single-symbol U+23DF / legacy FE38 markers only; other munder nodes use
    # MathType's unchanged original fallback.
    $taskUpdatedText = $taskText.Insert($taskActiveAnchors.Item(0).Index,$taskBlock)
    return [pscustomobject]@{ Changed=$true; Bytes=$taskEncoding.GetBytes($taskUpdatedText) }
}

function Write-TaskNewRuntimeFile {
    param([string]$Path,[byte[]]$Bytes)
    $taskStream = [IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $taskStream.Write($Bytes,0,$Bytes.Length); $taskStream.Flush() }
    finally { $taskStream.Dispose() }
}

function Enable-TaskMathMLRuntimeBudget {
    param(
        [Parameter(Mandatory=$true)][string]$TranslatorPath,
        [Parameter(Mandatory=$true)][string]$BackupDirectory,
        [switch]$EnableHorizontalBraces
    )
    $taskTarget = (Resolve-Path -LiteralPath $TranslatorPath -ErrorAction Stop).Path
    $taskOriginal = [IO.File]::ReadAllBytes($taskTarget)
    $taskPlan = Get-TaskMathMLRuntimePlan -Bytes $taskOriginal
    if ($EnableHorizontalBraces) {
        $taskBracePlan = Get-TaskMathMLHorizontalBracePlan -Bytes $taskPlan.Bytes
        $taskPlan.Changed = $taskPlan.Changed -or $taskBracePlan.Changed
        $taskPlan.Bytes = $taskBracePlan.Bytes
    }
    if (-not $taskPlan.Changed) { return [pscustomobject]@{ Changed=$false; Milliseconds=$taskPlan.Milliseconds; BackupPath=$null; Path=$taskTarget } }
    $taskOriginalHash = Get-TaskRuntimeHash -Bytes $taskOriginal
    $taskPlannedHash = Get-TaskRuntimeHash -Bytes $taskPlan.Bytes
    $taskBackupFolder = [IO.Path]::GetFullPath($BackupDirectory)
    [IO.Directory]::CreateDirectory($taskBackupFolder) | Out-Null
    $taskUnique = [Guid]::NewGuid().ToString('N')
    $taskBackup = Join-Path $taskBackupFolder ('MathML输入转换器_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+$taskUnique+'.tdl')
    Write-TaskNewRuntimeFile -Path $taskBackup -Bytes $taskOriginal
    if ((Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskBackup))) -cne $taskOriginalHash) { throw "配置备份校验失败；未修改 MathType：$taskBackup" }
    $taskTemp = $taskTarget+'.Codex.'+$taskUnique+'.tmp'
    $taskSwapBackup = $taskTemp+'.previous'
    try {
        Write-TaskNewRuntimeFile -Path $taskTemp -Bytes $taskPlan.Bytes
        if ((Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskTemp))) -cne $taskPlannedHash) { throw '待写入配置校验失败；未修改 MathType。' }
        if ((Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskTarget))) -cne $taskOriginalHash) { throw 'MathType 配置已被其他程序修改；保留该修改并停止。' }
        [IO.File]::Replace($taskTemp,$taskTarget,$taskSwapBackup)
        if ((Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskTarget))) -cne $taskPlannedHash) { throw "配置写后校验失败，请检查原配置备份：$taskBackup" }
        return [pscustomobject]@{ Changed=$true; Milliseconds=$taskPlan.Milliseconds; BackupPath=$taskBackup; Path=$taskTarget }
    } finally {
        if (Test-Path -LiteralPath $taskTemp) { Remove-Item -LiteralPath $taskTemp -Force }
        if ((Test-Path -LiteralPath $taskSwapBackup) -and (Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskTarget))) -ceq $taskPlannedHash -and (Get-TaskRuntimeHash -Bytes ([IO.File]::ReadAllBytes($taskBackup))) -ceq $taskOriginalHash) { Remove-Item -LiteralPath $taskSwapBackup -Force }
    }
}
