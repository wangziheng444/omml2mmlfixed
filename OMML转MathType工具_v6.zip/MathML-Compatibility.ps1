﻿# Normalize only known MathType import incompatibilities; preserve formula symbols.
function ConvertTo-MathTypeCompatibleMathML {
    param(
        [Parameter(Mandatory=$true)][string]$MathML,
        [ref]$Report
    )
    $taskMathNamespace = 'http://www.w3.org/1998/Math/MathML'
    $taskXML = New-Object System.Xml.XmlDocument
    $taskXML.PreserveWhitespace = $true
    $taskXML.LoadXml($MathML)
    $taskNamespaces = New-Object System.Xml.XmlNamespaceManager($taskXML.NameTable)
    $taskNamespaces.AddNamespace('mm', $taskMathNamespace)
    $taskBars = 0
    $taskSpaces = 0
    $taskComparisons = 0
    $taskGroups = 0
    $taskDoubleDots = 0
    # MathML 2 section 3.3.1.2.1: an attribute-free, single-argument mrow
    # is equivalent to its argument. Reduce redundant XSL wrappers before import.
    # Process descendants first, retaining compound, attributed and mixed groups.
    $taskRows = @($taskXML.SelectNodes('//mm:mrow', $taskNamespaces))
    for ($taskRowIndex = $taskRows.Count - 1; $taskRowIndex -ge 0; $taskRowIndex--) {
        $taskRow = $taskRows[$taskRowIndex]
        $taskArguments = $taskRow.SelectNodes('./*')
        if ($taskRow.Attributes.Count -ne 0 -or $taskArguments.Count -ne 1 -or $taskArguments.Item(0).NamespaceURI -ne $taskMathNamespace) { continue }
        $taskOnlyArgument = $true
        foreach ($taskChild in $taskRow.ChildNodes) {
            if ($taskChild.NodeType -eq [Xml.XmlNodeType]::Element) { continue }
            if ($taskChild.NodeType -in @([Xml.XmlNodeType]::Text,[Xml.XmlNodeType]::Whitespace,[Xml.XmlNodeType]::SignificantWhitespace) -and [string]::IsNullOrWhiteSpace($taskChild.Value)) { continue }
            $taskOnlyArgument = $false
            break
        }
        if ($taskOnlyArgument -and $null -ne $taskRow.ParentNode) {
            $taskRow.ParentNode.ReplaceChild($taskArguments.Item(0), $taskRow) | Out-Null
            $taskGroups++
        }
    }
    foreach ($taskMover in @($taskXML.SelectNodes('//mm:mover[@accent="true"]', $taskNamespaces))) {
        $taskChildren = $taskMover.SelectNodes('./*')
        if ($taskChildren.Count -eq 2 -and $taskChildren.Item(1).LocalName -in @('mi','mo') -and $taskChildren.Item(1).NamespaceURI -eq $taskMathNamespace -and $taskChildren.Item(1).SelectNodes('./*').Count -eq 0 -and $taskChildren.Item(1).InnerText -ceq [string][char]0x203E) {
            $taskMarker = $taskXML.CreateElement('mml', 'mo', $taskMathNamespace)
            $taskMarker.InnerText = [string][char]0x00AF
            $taskMarker.SetAttribute('stretchy', 'true')
            $taskMover.ReplaceChild($taskMarker, $taskChildren.Item(1)) | Out-Null
            $taskBars++
        }
        # OMML2MML.XSL converts combining diaeresis U+0308 to spacing U+00A8.
        # MathType's scalar cdot/2 rule accepts U+0308, but not U+00A8;
        # the latter falls through to an upper-limit template with a large gap.
        # Restore the equivalent marker only for a true accent on one character.
        # Compound/script bases and literal diaereses need different handling.
        if ($taskChildren.Count -eq 2 -and
            $taskChildren.Item(0).NamespaceURI -eq $taskMathNamespace -and
            $taskChildren.Item(0).LocalName -in @('mi','mo','mn') -and
            $taskChildren.Item(0).SelectNodes('./*').Count -eq 0 -and
            $taskChildren.Item(0).InnerText.Length -eq 1 -and
            $taskChildren.Item(1).NamespaceURI -eq $taskMathNamespace -and
            $taskChildren.Item(1).LocalName -in @('mi','mo') -and
            $taskChildren.Item(1).SelectNodes('./*').Count -eq 0 -and
            $taskChildren.Item(1).InnerText -ceq [string][char]0x00A8) {
            $taskChildren.Item(1).InnerText = [string][char]0x0308
            $taskDoubleDots++
        }
    }
    # ASCII/NBSP (the XSL maps ordinary spaces to NBSP), plus Unicode math spaces.
    # Widths are explicit MathML spacing, rather than glyphs in an operator font.
    $taskSpaceWidths = @{ 0x0020='0.25em'; 0x00A0='0.25em'; 0x2001='1em'; 0x2005='0.25em'; 0x2009='0.166667em'; 0x200B='0em' }
    foreach ($taskToken in @($taskXML.SelectNodes('//mm:mi | //mm:mo | //mm:mn | //mm:mtext', $taskNamespaces))) {
        $taskText = $taskToken.InnerText
        if ($taskText.Length -eq 1 -and $taskToken.SelectNodes('./*').Count -eq 0) {
            $taskCode = [int][char]$taskText[0]
            if ($taskSpaceWidths.ContainsKey($taskCode)) {
                $taskSpace = $taskXML.CreateElement('mml', 'mspace', $taskMathNamespace)
                $taskSpace.SetAttribute('width', $taskSpaceWidths[$taskCode])
                $taskToken.ParentNode.ReplaceChild($taskSpace, $taskToken) | Out-Null
                $taskSpaces++
            }
        }
    }
    # MathType pairs stretchy < and > as angle fences even when fence=false.
    # Preserve explicit delimiters; ordinary comparison tokens must not stretch.
    foreach ($taskOperator in @($taskXML.SelectNodes('//mm:mo', $taskNamespaces))) {
        if ($taskOperator.SelectNodes('./*').Count -eq 0 -and $taskOperator.InnerText -in @('<','>') -and $taskOperator.GetAttribute('fence') -notin @('true','1') -and $taskOperator.GetAttribute('form') -notin @('prefix','postfix')) {
            if ($taskOperator.GetAttribute('stretchy') -ne 'false' -or $taskOperator.GetAttribute('fence') -ne 'false' -or $taskOperator.GetAttribute('form') -ne 'infix') {
                $taskOperator.SetAttribute('stretchy','false')
                $taskOperator.SetAttribute('fence','false')
                $taskOperator.SetAttribute('form','infix')
                $taskComparisons++
            }
        }
    }
    if ($null -ne $Report) {
        $Report.Value = [pscustomobject]@{ Bars=$taskBars; Spaces=$taskSpaces; Comparisons=$taskComparisons; Groups=$taskGroups; DoubleDots=$taskDoubleDots }
    }
    return $taskXML.OuterXml
}
